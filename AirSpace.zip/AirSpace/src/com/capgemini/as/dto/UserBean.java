package com.capgemini.as.dto;


/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Creating a class of User named UserBean
 * Creation date	=		04/12/2017
 */

public class UserBean {

	private String name;
	private String userName;
	private String password;
	private String mobileNumber;
	
	/**
	 * No parameter Contructor
	 */
	public UserBean() {
		super();
	}

	/**
	 * Parameterized Constructor
	 * @param name
	 * @param userName
	 * @param password
	 * @param mobileNumber
	 */
	public UserBean(String name, String userName, String password,
			String mobileNumber) {
		super();
		this.name = name;
		this.userName = userName;
		this.password = password;
		this.mobileNumber = mobileNumber;
	}

/**
 * 
 * Getters and setters
 */

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	

}
