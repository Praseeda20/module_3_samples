package com.capgemini.as.util;

/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		DataBase Connection Class
 * Creation date	=		04/12/2017
 */

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.as.exception.UsersException;

public class DBUtil {

	public static Connection getConnection() throws UsersException,SQLException{
		Connection connection = null;
		try {
			InitialContext context = new InitialContext();
			DataSource dataSource;
			dataSource = (DataSource) context.lookup("java:/oracleDs");
			connection = dataSource.getConnection();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
		}
		return connection;

	}
}
