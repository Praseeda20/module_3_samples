package com.capgemini.as.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.as.dto.UserBean;
import com.capgemini.as.exception.UsersException;
import com.capgemini.as.util.DBUtil;

public class CustomerDAO implements ICustomerDAO {
	
	/*
	 * Emp Id			=		139710
	 * Employee Name	=		Jatin Nair
	 * Description		=		Implementing the Customer DAO Interface 
	 * 							To insert the user records to the database
	 * Input Parameter  =       UserBean Object
	 * Return Type      =       Boolean
	 * Creation date	=		04/12/2017
	 */
	

	@Override
	public boolean register(UserBean userBean) throws UsersException {
		boolean isInserted = false;
		int result = 0;
		
		try {
			Connection con = DBUtil.getConnection();
					PreparedStatement preparedSt = con.prepareStatement(QueryMapperUsers.REGISTER_USER);
					//calling the QueryMapper for the function
				
				preparedSt.setString(1, userBean.getName());
				preparedSt.setString(2, userBean.getUserName());
				preparedSt.setString(3, userBean.getPassword());
				preparedSt.setString(4, userBean.getMobileNumber());
				
				result = preparedSt.executeUpdate();
				
				if(result > 0){
					isInserted = true;
				}
				con.close();
		} catch (SQLException e) {

			throw new UsersException(e.getMessage());
			
		}catch(UsersException ue){
			throw new UsersException("Error while inserting records into database");
		}
		return isInserted;
		
		//returns the boolean value to the controller
	}

}
