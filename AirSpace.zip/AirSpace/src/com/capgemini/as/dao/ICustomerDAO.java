package com.capgemini.as.dao;


/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Customer DAO Interface
 * Creation date	=		04/12/2017
 */


import com.capgemini.as.dto.UserBean;
import com.capgemini.as.exception.UsersException;

public interface ICustomerDAO {

	
	boolean register(UserBean userBean) throws UsersException; 
	//returns boolean value after inserting records to database, to Service Layer
}
