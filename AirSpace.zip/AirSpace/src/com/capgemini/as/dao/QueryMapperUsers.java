package com.capgemini.as.dao;


/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Query Mapper for Users table in database
 * Creation date	=		04/12/2017
 */

public interface QueryMapperUsers {
	
	
	/**
	 * Insert query
	 */
	public static final String REGISTER_USER = "INSERT INTO users (name,user_name,password,mobile_number) VALUES (?,?,?,?)";
}
