package com.capgemini.as.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.as.dto.UserBean;
import com.capgemini.as.exception.UsersException;
import com.capgemini.as.service.CustomerService;
import com.capgemini.as.service.ICustomerService;

/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Created ProcessUser servlet
 * Creation date	=		04/12/2017
 */



/**
 * Servlet implementation class ProcessUser
 */
@WebServlet({"/Register", "/Insert", "PayBill", "Success"}) //Servlet Annotations
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessUser() {
        super();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(true); //Session set to true
		String path = request.getServletPath().trim();
		String target = "";
		
		
		switch(path){
			//If path is Register
			case "/Register" :
				target="WEB-INF/pages/Register.jsp";
				break;
				
				
				//If path is Insert		
			case "/Insert" :
				
				
				String name=request.getParameter("name");
				String mobileNo=request.getParameter("mobileNo");
				String userName=request.getParameter("userName");
				String password=request.getParameter("password");
				
				UserBean userBean=new UserBean(); //UserBean Object Created
				
				userBean.setName(name);
				userBean.setMobileNumber(mobileNo);
				userBean.setUserName(userName);
				userBean.setPassword(password);

				ICustomerService customerService = new CustomerService(); //CustomerService Object Created
				
				try {
					boolean flag = customerService.registerUser(userBean);
					System.out.println(flag);
					if(flag)
					{
						session.setAttribute("userName",userName);
						session.setAttribute("mobileNo",mobileNo);
						target="WEB-INF/pages/CustomerHome.jsp"; //target variable set to the CustomerHome page path 
					}
				} catch (UsersException ue) {
					request.setAttribute("errMsg", ue.getMessage());
					target="WEB-INF/pages/error.jsp"; //target variable set to the Error page path
				}
				break;
				
				//If path is PayBill
			case "/PayBill" : 
				
				target="WEB-INF/pages/PayBill.jsp"; //target variable set to the PayBill Page path
				break;
				
				
				
				//If path is Success
			case "/Success" :
				
				int amount = Integer.parseInt(request.getParameter("amount"));
				int toBePaid = 750;
				int balance = toBePaid - amount;
				session.setAttribute("balance",balance); //Balance amount
				
				target = "WEB-INF/pages/Success.jsp"; //target variable set to the Success Page path
				break;
			}
		
	
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response); //forwards to the target page
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response); //Calling doGet method
	}
	
}
