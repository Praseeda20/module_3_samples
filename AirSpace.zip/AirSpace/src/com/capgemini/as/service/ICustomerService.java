package com.capgemini.as.service;


/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Customer Service Interface
 * Creation date	=		04/12/2017
 */

import com.capgemini.as.dto.UserBean;
import com.capgemini.as.exception.UsersException;

public interface ICustomerService {

	public boolean registerUser(UserBean userBean) throws UsersException;
	//Returns boolean value to the controller
}
