package com.capgemini.as.service;

import com.capgemini.as.dao.CustomerDAO;
import com.capgemini.as.dao.ICustomerDAO;
import com.capgemini.as.dto.UserBean;
import com.capgemini.as.exception.UsersException;

/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		Implementing the Customer Service Interface
 * Creation date	=		04/12/2017
 */

public class CustomerService implements ICustomerService {

	
	@Override
	public boolean registerUser(UserBean userBean) throws UsersException {
		ICustomerDAO customerDao = new CustomerDAO();
		return customerDao.register(userBean);
		//returns the boolean value to the controller
	}

}
