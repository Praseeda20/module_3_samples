package com.capgemini.as.exception;


/*
 * Emp Id			=		139710
 * Employee Name	=		Jatin Nair
 * Description		=		User Exception Class extending Exception Class
 * Input Parameter  =       String
 * Creation date	=		04/12/2017
 */

public class UsersException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1543154407141014719L;

	public UsersException(String message) {
		super(message);
	}

	
	
}
