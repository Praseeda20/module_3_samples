package com.cg.lpg.exception;

public class LPGException extends Exception{

	public LPGException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LPGException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public LPGException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LPGException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LPGException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
