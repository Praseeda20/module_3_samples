package com.cg.olg.service;

import java.util.ArrayList;

import com.cg.olg.bean.OnlineGamingBean;
import com.cg.olg.dao.OnlineGamingDao;
import com.cg.olg.dao.OnlineGamingDaoImpl;
import com.cg.olg.exception.GamingException;

public class OnlineGamingServiceImpl implements OnlineGamingService{
	
	OnlineGamingDao gamingDao = new OnlineGamingDaoImpl();
	
	@Override
	public ArrayList<OnlineGamingBean> viewAllGames()
			throws GamingException {	
		return gamingDao.viewAllGames();
	}

	@Override
	public OnlineGamingBean bookGame(int gameId) throws GamingException {
		return gamingDao.bookGame(gameId);
	}

	@Override
	public void showPrice(int gameId) throws GamingException {
		gamingDao.showPrice(gameId);
		
	}

}
