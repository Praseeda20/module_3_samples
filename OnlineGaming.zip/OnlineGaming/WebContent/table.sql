create table onlineGaming
(gameId number(5) primary key,
gameName varchar2(25),
price number(6,2),
slot number(5));


insert into onlineGaming values(1001,'Counter Strike GO', 400, 10 );
insert into onlineGaming values(1002,'FIFA 17', 3999, 6 );
insert into onlineGaming values(1003,'Overwatch', 4000, 16 );
insert into onlineGaming values(1004,'COD', 2899, 20 );
insert into onlineGaming values(1005,'Assassin Creed Syndicate', 3000, 13 );
insert into onlineGaming values(1006,'GTA 5', 2000, 24 );
